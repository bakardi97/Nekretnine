from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect
from ...modeli.komentari_model import KomentariModel
from .ostavi_komentar_dialog import OstaviKomentarDialog
import datetime

class DetaljiOglasaDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, oglasID=None, userData=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()

        self.userData = userData
        self.oglasID = oglasID
        self.nekretnina_id = -1

        oglasInfoList = self.preuzmiIzBaze()
        
        self.registerState = False

        self.setWindowTitle("Detalji Oglasa")

        self.vbox_layout = QtWidgets.QVBoxLayout()
        self.hbox_layout = QtWidgets.QHBoxLayout()
        self.hbox_layout1 = QtWidgets.QHBoxLayout()

        self.table_view = QtWidgets.QTableView(self)
        self.set_model()

        self.ostavi_komentarBTN = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/application--pencil.png"), "Ostavi Komentar", self)
        self.hbox_layout1.addWidget(self.ostavi_komentarBTN)
        self.ostavi_komentarBTN.clicked.connect(self.onOstaviKomentar)

        if userData["loginState"]:
            if userData["korisnikTIP"] == 1:
                self.zakupiBTN = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/building-hedge.png"), "Zakupi", self)
                self.hbox_layout1.addWidget(self.zakupiBTN)
                self.zakupiBTN.clicked.connect(self.onZakupi)

        self.strOglasLabel = QtWidgets.QLabel(self)
        self.strOglasLabel.setText(oglasInfoList[0])

        self.strNekretninaLabel  = QtWidgets.QLabel(self)
        self.strNekretninaLabel.setText(oglasInfoList[1])

        self.strAgencijaLabel = QtWidgets.QLabel(self)
        self.strAgencijaLabel.setText(oglasInfoList[2])

        self.strTipLabel = QtWidgets.QLabel(self)
        self.strTipLabel.setText(oglasInfoList[3])

        self.hbox_layout.addWidget(self.strOglasLabel)
        self.hbox_layout.addWidget(self.strNekretninaLabel)
        self.hbox_layout.addWidget(self.strAgencijaLabel)
        self.hbox_layout.addWidget(self.strTipLabel)
        
        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)

        self.vbox_layout.addLayout(self.hbox_layout1)
        self.vbox_layout.addLayout(self.hbox_layout)
        self.vbox_layout.addWidget(self.table_view)
        self.vbox_layout.addWidget(self.button_box)
        
        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)

    def _on_accept(self):
        self.accept()
    def get_data(self):
        return {}
    
    def preuzmiIzBaze(self):
        self._c = self._conn.execute("""SELECT * 
        FROM oglasi INNER join nekretnine ON oglasi.nekretnina_id = nekretnine.id_nekretnina
        INNER JOIN agencija ON agencija.agencija_id = nekretnine.agencija_id
        WHERE oglas_id = :oID
         """, {"oID" : self.oglasID } )
        rezLista = list(self._c.fetchall())

        self.nekretnina_id = rezLista[0][3]
        strOglas = "Naslov: "+ str(rezLista[0][1])
        strOglas+= "\nVlasnik: "+  str(rezLista[0][2])
        strOglas+="\nTip: "+ str(rezLista[0][4])
        strOglas+="\nperiod od: "+ str(rezLista[0][5])
        strOglas+="\nperiod do: "+ str(rezLista[0][6])
        strOglas+="\nOpis: "+ str(rezLista[0][7]   ) 

        strNekretnina = "Lokacija "+ str(rezLista[0][9])
        if rezLista[0][10] == 1:
            strNekretnina +="\nLegalizovana: DA"
        else:
            strNekretnina +="\nLegalizovana: NE"

        if rezLista[0][11] == 1:
            strNekretnina +="\nHipoteka: DA"
        else:
            strNekretnina +="\nHipoteka: NE"

        strNekretnina +="\nVrsta Nekretnine: "+ str(rezLista[0][12])
        strNekretnina +="\nLokacija: "+ str(rezLista[0][9])

        strAgencija = "Agencija: "+ str(rezLista[0][15])
        strAgencija+="\nAgencija email: "+ 	str(rezLista[0][17])
        strAgencija+="\nAgencija telefon: "+ 	str(rezLista[0][18])
        

        rezLista2=[]
        if (rezLista[0][12] == "kuca"):
            self._c = self._conn.execute("""SELECT * 
            FROM kuca WHERE id=:id
            """ , { "id":rezLista[0][13] } )
            rezLista2 = list(self._c.fetchall())
            strTip = "KUCA"
            strTip += "\nbroj spratova: " +	str(rezLista2[0][0])
            strTip+="\nbroj soba: "	+str(rezLista2[0][1])
            strTip+="\nbroj kupatila: "+str(rezLista2[0][2])
            strTip+="\nbroj kuhinja: "+str(rezLista2[0][3])
            strTip+="\npovrsina: "+str(rezLista2[0][4])
            strTip+="\nprateci objekti: "+str(rezLista2[0][5])
        
        elif (rezLista[0][12] == "stan"):
            self._c = self._conn.execute("""SELECT * 
            FROM stan WHERE id=:id
            """ , {"id":rezLista[0][13] } )
            rezLista2 = list(self._c.fetchall())
            strTip = "STAN"
            strTip+="\nsprat stana:	"+str(rezLista2[0][1])
            strTip+="\nukupno sprata u zgradi: " +str(rezLista2[0][2])
            strTip+="\nprateci objekti: "+str(rezLista2[0][3])
            strTip+="\nbroj soba: "+	str(rezLista2[0][4])
            strTip+="\nbroj kupatila: "+	str(rezLista2[0][5])
            strTip+="\nbroj kuhinja: "+str(rezLista2[0][6])
            strTip+="\npovrsina: "+str(rezLista2[0][7])
        
        elif (rezLista[0][12] == "garaza"):
            self._c = self._conn.execute("""SELECT * 
            FROM garaza WHERE id=:id
            """ , {"id":rezLista[0][13] } )
            rezLista2 = list(self._c.fetchall())
            strTip = "GARAZA"
            strTip += "\nbroj mesta: "+str(rezLista2[0][1])
            strTip+="\npovrsina: " + str(rezLista2[0][2])

        return [strOglas , strNekretnina , strAgencija, strTip]


    def set_model(self):
        self.table_view.setModel(KomentariModel(self.oglasID))
        self.table_view.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)


    def onZakupi(self):
        #provera ako je zakupljena izbaci ERROR
        #ako moze da se zakupi +++
        self._c = self._conn.execute("SELECT * FROM zakupljene_nekretnine WHERE id_nekretnine = :idNekretnine" ,
            {'idNekretnine' : self.nekretnina_id} )

        rezLista = list(self._c.fetchall())
        if(not len(rezLista)==0):
            QtWidgets.QMessageBox.warning(self, 
            "ZAKUPLJENA", "Ova nekretnina je već zakupljena!", QtWidgets.QMessageBox.Ok)
            return

        if(rezLista):
            newID = rezLista[0][0] + 1
        else:
            newID = 1

        QtWidgets.QMessageBox.information(self, 
            "ZAKUPILI STE", "Zakupili ste nekretninu!", QtWidgets.QMessageBox.Ok)
        
        x = datetime.datetime.now()
        dateFormat = x.strftime("%x")
        self._c = self._conn.cursor() 
        self._c = self._conn.execute("""
        INSERT INTO zakupljene_nekretnine(id_zakupljene, id_nekretnine, id_korisnik, datum)
        VALUES (:ID, :IDn, :idK, :datum)
        """,
        { "ID" : newID,
         "IDn" :self.nekretnina_id,
        "idK" : self.userData["korisnikID"],
        "datum" : dateFormat
        })
        self._conn.commit()
        return
    def onOstaviKomentar(self):

        dialog = OstaviKomentarDialog(self.parent(), self.oglasID, self.userData)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            self.set_model()
        return
    



