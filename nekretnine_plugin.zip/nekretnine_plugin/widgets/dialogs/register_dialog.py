from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect

class RegisterDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self.korisnikID = -1

        self.registerState = False

        self.setWindowTitle("REGISTER")

        self.vbox_layout = QtWidgets.QVBoxLayout()
        self.form_layout = QtWidgets.QFormLayout()

        self.user_input = QtWidgets.QLineEdit(self)
        self.password_input = QtWidgets.QLineEdit(self)
        self.password_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)


        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)

        self.form_layout.addRow("Korisničko Ime:", self.user_input)
        self.form_layout.addRow("Lozinka:", self.password_input)

        self.vbox_layout.addLayout(self.form_layout)
        self.vbox_layout.addWidget(self.button_box)

        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)

    def _on_accept(self):
        if self.user_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera Korisničkog imena", "Korisničko mora biti popunjeno!", QtWidgets.QMessageBox.Ok)
            return

        if self.password_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera lozinke", "Lozinka mora biti popunjena!", QtWidgets.QMessageBox.Ok)
            return

        self._c = self._conn.execute("SELECT korisnik_id FROM korisnik WHERE korisnik_ime == :kIme" ,
            {'kIme' : self.user_input.text()} )
        
        rezLista = list(self._c.fetchall())
        if(rezLista):
            QtWidgets.QMessageBox.warning(self, 
            "Provera", "Korisničko ime postoji u bazi!", QtWidgets.QMessageBox.Ok)
            return
        ##################################################################################################
        self._c = self._conn.execute("SELECT korisnik_id FROM korisnik ORDER BY korisnik_id DESC LIMIT 1")
        k_fetch = self._c.fetchall()

        if(k_fetch):
            newID = k_fetch[0][0] + 1
        else:
            newID = 1
        
        self._c = self._conn.cursor() 
        self._c = self._conn.execute("""
        INSERT INTO korisnik(korisnik_id, korisnik_ime, lozinka, tip, agencija_id)
        VALUES (:ID, :kIme, :kLozinka, :kTip, :agenID   )
        """,
        { "ID" : newID,
         "kIme" :self.user_input.text(),
        "kLozinka" : self.password_input.text(),
        "kTip": 1,
        "agenID" : -1
        })
        self._conn.commit()
        self.registerState = True
        #kTip 1 - korisnik
        #kTip 2 - agencija
        
        self.accept()
    def get_data(self):
        return {
            "register" : self.registerState,
        }
    



