from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect
from ...modeli.postavljeni_oglasi_model import PostavljeniOglasiModel
from .postavi_oglas_dialog import PostaviOglasDialog

class PrikazPostavljenihOglasaDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, userData=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self.agencijaID = -1
        self.userData = userData
        self.izabranCombobox = "kuca"

        self.setAgencijaID()

        self.setWindowTitle("Prikaz Postavljenih Oglasa")
        self.resize(600, 600)

        self.vbox_layout = QtWidgets.QVBoxLayout()

        self.postavi_oglasBTN = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/application-share.png"), "Postavi Oglas", self)
        
        self.postavi_oglasBTN.clicked.connect(self.onPostaviOglas)

        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)


        self.table_view = QtWidgets.QTableView(self)
        self.setTableView()

        self.vbox_layout.addWidget(self.postavi_oglasBTN)
        self.vbox_layout.addWidget(self.table_view)
        self.vbox_layout.addWidget(self.button_box)

        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)


    def _on_accept(self):
        self.accept()
    def get_data(self):
        return {}
    
    def setAgencijaID(self):
        result = self._conn.execute(""" 
        SELECT agencija_id FROM korisnik WHERE korisnik_id = :IDk
        """, {"IDk": self.userData["korisnikID"]})
        rezLista = list(result.fetchall())
        self._conn.commit()
        self.agencijaID = rezLista[0][0]

    def onPostaviOglas(self):
        dialog = PostaviOglasDialog(self.parent())
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            dialog.get_data()
            self.setTableView()
        
    def setTableView(self):
        self.table_view.setModel(PostavljeniOglasiModel(self.agencijaID))
        self.table_view.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)

    



