from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect
import re

class OstaviKomentarDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, oglasID=None, userData=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self.korisnikID = -1
        self.oglasID = oglasID
        self.userData = userData


        self.setWindowTitle("Ostavi komentar!")

        self.vbox_layout = QtWidgets.QVBoxLayout()
        self.form_layout = QtWidgets.QFormLayout()

        self.ktel_input = QtWidgets.QLineEdit(self)
        self.kemail_input = QtWidgets.QLineEdit(self)
        self.text_input = QtWidgets.QLineEdit(self)



        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)

        if not self.userData["loginState"]:
            self.iip_input = QtWidgets.QLineEdit(self)
            self.form_layout.addRow("Ime I prezime:", self.iip_input)


        self.form_layout.addRow("Telefon:", self.ktel_input)
        self.form_layout.addRow("Email:", self.kemail_input)
        self.form_layout.addRow("Komentar:", self.text_input)

        self.vbox_layout.addLayout(self.form_layout)
        self.vbox_layout.addWidget(self.button_box)

        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)

    def _on_accept(self):
        if not self.userData["loginState"]:
            if self.iip_input.text() == "" :
                QtWidgets.QMessageBox.warning(self, 
                "Provera telefon ", "Tel mora biti popunjeno, 10cifara potrebno!", QtWidgets.QMessageBox.Ok)
                return

        if self.ktel_input.text() == "" and not re.search("^[0-9]{10}$", self.ktel_input.text()):
            QtWidgets.QMessageBox.warning(self, 
            "Provera telefon ", "Tel mora biti popunjeno, 10cifara potrebno!", QtWidgets.QMessageBox.Ok)
            return
    
        if self.kemail_input.text() == "" and not re.search("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", self.kemail_input.text()):
            QtWidgets.QMessageBox.warning(self, 
            "Provera email", "email mora biti popunjeno!", QtWidgets.QMessageBox.Ok)
            return
        
        if self.text_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera komentara", "komentar mora biti popunjen!", QtWidgets.QMessageBox.Ok)
            return


        self._c = self._conn.execute("SELECT komentar_id FROM komentar ORDER BY komentar_id DESC LIMIT 1")
        k_fetch = self._c.fetchall()

        if(k_fetch):
            newID = k_fetch[0][0] + 1
        else:
            newID = 1
        
        if not self.userData["loginState"]:
            iip = self.iip_input.text()
        else:
            iip = self.userData["korisnickoime"]

        self._c = self._conn.cursor() 
        self._c = self._conn.execute("""
        INSERT INTO komentar (komentar_id, ime_prezime, kontakt_tel, kontakt_email, komentar_tekst, oglas_id)
        VALUES (:ID, :iip, :tel, :email, :text, :oglasID)
        """,
        { "ID" : newID,
        "iip" :iip,
        "tel" :  self.ktel_input.text(),
        "email": self.kemail_input.text(),
         "text" : self.text_input.text(),
         "oglasID" : self.oglasID
        })
        self._conn.commit()

        
        self.accept()
    def get_data(self):
        return {}
    



