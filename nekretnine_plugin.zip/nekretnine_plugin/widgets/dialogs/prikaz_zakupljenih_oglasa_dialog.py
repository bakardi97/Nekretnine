from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect
from ...modeli.zakupljeni_oglasi_model import ZakupljeniOglasiModel

class PrikazZakupljenihOglasaDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, userData=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self.korisnikID = -1
        self.korisnikTIP = -1
        self.userData = userData

        self.loggedInState = False

        self.setWindowTitle("Prikaz Zakupljenih Oglasa")
        self.resize(600, 600)

        self.vbox_layout = QtWidgets.QVBoxLayout()


        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)


        self.table_view = QtWidgets.QTableView(self)
        self.table_view.setModel(ZakupljeniOglasiModel(self.userData["korisnikID"]))
        self.table_view.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)

        self.vbox_layout.addWidget(self.table_view)
        self.vbox_layout.addWidget(self.button_box)

        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)

    def _on_accept(self):
        self.accept()
    def get_data(self):
        return {}
    



