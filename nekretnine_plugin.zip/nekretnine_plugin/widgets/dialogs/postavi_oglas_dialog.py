from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect
import re

class PostaviOglasDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self.choice_tip_oglasavanja_combobox = "prodaja"
        self.nekretninelListCombobox =[]
        self.nekretninelListComboboxIDs =[]
        

        self.setWindowTitle("Postavi Oglas")

        self.vbox_layout = QtWidgets.QVBoxLayout()
        self.form_layout = QtWidgets.QFormLayout()

        self.naslov_input               = QtWidgets.QLineEdit(self)
        self.vlasnik_input              = QtWidgets.QLineEdit(self)
        self.tip_oglasavanja_combobox   = QtWidgets.QComboBox(self)
        self.period_od_input            = QtWidgets.QLineEdit(self)
        self.period_do_input            = QtWidgets.QLineEdit(self)
        self.opis_input                 = QtWidgets.QLineEdit(self)
        self.nekretnina_combobox        = QtWidgets.QComboBox(self)

        self.setUpNekretnine()

        self.tip_oglasavanja_combobox.addItems(["prodaja", "iznajmljivanje"])
        self.tip_oglasavanja_combobox.currentTextChanged.connect(self.onChangeTipOglasavanja)

        self.nekretnina_combobox.addItems(self.nekretninelListCombobox)
        self.nekretnina_combobox.currentTextChanged.connect(self.onChangeNekretnina)
        


        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)

        self.form_layout.addRow("Naslov:", self.naslov_input)
        self.form_layout.addRow("Vlasnik:", self.vlasnik_input)
        self.form_layout.addRow("Tip Oglasavanja:", self.tip_oglasavanja_combobox)
        self.form_layout.addRow("Period od :", self.period_od_input)
        self.form_layout.addRow("Period do:", self.period_do_input)
        self.form_layout.addRow("Opis:", self.opis_input)
        self.form_layout.addRow("Nekretnina:", self.nekretnina_combobox)

        self.vbox_layout.addLayout(self.form_layout)
        self.vbox_layout.addWidget(self.button_box)

        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)

    def _on_accept(self):
        if self.naslov_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera Naslova", "Naslov mora biti popunjen!", QtWidgets.QMessageBox.Ok)
            return
        if self.vlasnik_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera vlasnika", "Vlasnik mora biti popunjen!", QtWidgets.QMessageBox.Ok)
            return
        if self.period_od_input.text() == "" and not (re.search("^\d{2}\/\d{2}\/\d{2}$", self.period_od_input.text()) or self.period_od_input.text() == "neograniceno" ):
            QtWidgets.QMessageBox.warning(self, 
            "Provera PERIDO OD", "Period od mora biti popunjen : primer dobro: 01/01/19 ILI neograniceno!", QtWidgets.QMessageBox.Ok)
            return
        if self.period_do_input.text() == ""and not (re.search("^\d{2}\/\d{2}\/\d{2}$", self.period_do_input.text()) or self.period_do_input.text() == "neograniceno" ):
            QtWidgets.QMessageBox.warning(self, 
            "Provera period do", "Period do mora biti popunjen : primer dobro: 01/01/19 ILI neograniceno!", QtWidgets.QMessageBox.Ok)
            return
        if self.opis_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera opis", "Opis mora biti popunjen!", QtWidgets.QMessageBox.Ok)
            return

        self._c = self._conn.execute("SELECT oglas_id FROM oglasi ORDER BY oglas_id DESC LIMIT 1")
        k_fetch = self._c.fetchall()

        if(k_fetch):
            newID = k_fetch[0][0] + 1
        else:
            newID = 1


        self._c = self._conn.cursor() 
        self._c = self._conn.execute("""
        INSERT INTO oglasi (oglas_id, podaci_naslov, vlasnik, nekretnina_id, tip_oglasivanja, period_od, period_do, text_opis)
        VALUES (:oglas_id, :podaci_naslov, :vlasnik, :nekretnina_id, :tip_oglasivanja, :period_od, :period_do, :text_opis)
        """,
        { "oglas_id" : newID,
         "podaci_naslov"    : self.naslov_input.text(),
        "vlasnik"           : self.vlasnik_input.text(),
        "nekretnina_id"     : self.nekretninelListComboboxIDs[self.nekretnina_combobox.currentIndex()], 
        "tip_oglasivanja"   : self.choice_tip_oglasavanja_combobox, 
        "period_od"         : self.period_od_input.text(),
        "period_do"         : self.period_do_input.text(),
        "text_opis"         : self.opis_input.text(),
        })
        self._conn.commit()
        

        self.accept()
    def get_data(self):
        return {}
    
    def onChangeTipOglasavanja(self):
        index = self.tip_oglasavanja_combobox.currentIndex()
        if index == 0:
            self.choice_tip_oglasavanja_combobox = "prodaja"
        elif index == 1:
            self.choice_tip_oglasavanja_combobox = "iznajmljivanje"
        self.setUpNekretnine()
        return

    def onChangeNekretnina(self):
        print(self.nekretninelListComboboxIDs[self.nekretnina_combobox.currentIndex()])
        return
       

    def setUpNekretnine(self):
        self.nekretnina_combobox.clear()
        self.nekretninelListCombobox = []
        self.nekretninelListComboboxIDs = []
        self._c = self._conn.execute("""
                SELECT id_nekretnina, lokacija, vrsta_nekretnine 
                FROM nekretnine
         """ )
        nekretnineLista = list(self._c.fetchall())

        for i in range (0, len(nekretnineLista)):
            self._c = self._conn.execute("""
                SELECT * from oglasi WHERE nekretnina_id = :IDn AND tip_oglasivanja = :Otip
            """, {"IDn": nekretnineLista[i][0], "Otip" : self.choice_tip_oglasavanja_combobox  } )
            tempLIST = list(self._c.fetchall())
            if not tempLIST:
                self.nekretninelListCombobox.append(str(nekretnineLista[i][0])+"    "+str(nekretnineLista[i][1])+"   "+str(nekretnineLista[i][2]))
                self.nekretninelListComboboxIDs.append(nekretnineLista[i][0])
        
        self.nekretnina_combobox.addItems(self.nekretninelListCombobox)





