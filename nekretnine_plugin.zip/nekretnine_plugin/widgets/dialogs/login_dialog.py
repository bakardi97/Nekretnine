from PySide2 import QtWidgets, QtCore, QtGui
from ...podaci_za_bazu import db_connect

class LoginDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self.korisnikID = -1
        self.korisnikTIP = -1

        self.loggedInState = False

        self.setWindowTitle("Login")

        self.vbox_layout = QtWidgets.QVBoxLayout()
        self.form_layout = QtWidgets.QFormLayout()

        self.user_input         = QtWidgets.QLineEdit(self)
        self.password_input     = QtWidgets.QLineEdit(self)
        self.password_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)


        self.button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok 
            | QtWidgets.QDialogButtonBox.Cancel, parent=self)

        self.form_layout.addRow("Korisničko Ime:", self.user_input)
        self.form_layout.addRow("Lozinka:", self.password_input)

        self.vbox_layout.addLayout(self.form_layout)
        self.vbox_layout.addWidget(self.button_box)

        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(self.vbox_layout)

    def _on_accept(self):
        if self.user_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera Korisničkog imena", "Korisničko mora biti popunjeno!", QtWidgets.QMessageBox.Ok)
            return

        if self.password_input.text() == "":
            QtWidgets.QMessageBox.warning(self, 
            "Provera lozinke", "Lozinka mora biti popunjena!", QtWidgets.QMessageBox.Ok)
            return

        self._c = self._conn.execute("SELECT korisnik_id, korisnik_ime , lozinka, tip FROM korisnik WHERE korisnik_ime = :kIme AND lozinka = :klozinka " ,
            {'kIme' : self.user_input.text(), 'klozinka' : self.password_input.text()} )
        
        rezLista = list(self._c.fetchall())
        if not (rezLista):
            QtWidgets.QMessageBox.warning(self, 
            "Provera", "Korisničko ime i lozinka se ne poklapaju sa bazom!", QtWidgets.QMessageBox.Ok)
            return

        self.korisnikID = rezLista[0][0]
        self.korisnikTIP = rezLista[0][3]

        self.loggedInState = True
        

        self.accept()
    def get_data(self):
        return {
            "loginState" : self.loggedInState,
            "korisnickoime" : self.user_input.text(),
            "korisnikID" : self.korisnikID,
            "korisnikTIP" : self.korisnikTIP
        }
    



