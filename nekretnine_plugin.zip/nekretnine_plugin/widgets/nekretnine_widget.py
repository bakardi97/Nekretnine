from PySide2 import QtWidgets
from PySide2 import QtGui
from .dialogs.login_dialog import LoginDialog
from .dialogs.register_dialog import RegisterDialog
from .dialogs.detalji_oglasa_dialog import DetaljiOglasaDialog
from ..modeli.aktuelni_oglasi_model import AktuelniOglasiModel
from .dialogs.prikaz_zakupljenih_oglasa_dialog import PrikazZakupljenihOglasaDialog
from .dialogs.prikaz_postavljenih_oglasa_dialog import PrikazPostavljenihOglasaDialog


class NekretnineWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        #setting up init values
        self.userData = {"loginState" : False, "korisnickoime" :"", "korisnikID" : "",  "korisnikTIP" : -1}

        self.vbox_layout = QtWidgets.QVBoxLayout()
        self.hbox_layout = QtWidgets.QHBoxLayout()
        #login/logout lock--minus
        self.login_btn = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/lock.png"), "Login", self)
        self.register_btn = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/lock--pencil.png"), "Register", self)
        self.detalji_oglasa = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/address-book-open.png"), "Detalji Oglasa", self)
        self.prikaz_oglasa = QtWidgets.QPushButton(QtGui.QIcon("resources/icons/address-book-blue.png"), "Prikaz Oglasa", self)
        self.table_view = QtWidgets.QTableView(self)
        self.set_model()
        
        self.onSetUp()

    def onLogin(self):
        if(self.userData["loginState"]):
            self.login_btn.setText("Login")
            self.login_btn.setIcon(QtGui.QIcon("resources/icons/lock.png"))
            self.userData = {"loginState" : False, "korisnickoime" :"", "korisnikID" : "",  "korisnikTIP" : -1}
            return



        dialog = LoginDialog(self.parent())
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            dataD = dialog.get_data()
            self.userData = dataD
            #call dialog = check if login true set to true && change the text && icon
            if(not self.userData["loginState"]):
                self.login_btn.setText("Login")
                self.login_btn.setIcon(QtGui.QIcon("resources/icons/lock.png"))
            else :
                self.login_btn.setText("LOGOUT")
                self.login_btn.setIcon(QtGui.QIcon("resources/icons/lock--minus.png"))

    def onRegister(self):
        dialog = RegisterDialog(self.parent())
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            dialog.get_data()
    
    def onDetaljiOglasa(self):
        rows = sorted(set(index.row() for index in
                      self.table_view.selectedIndexes()))
        if len(rows) == 0:
            return
        oglasID = self.table_view.model().getID_clicked(rows[0])
        
        dialog = DetaljiOglasaDialog(self.parent(), oglasID, self.userData )
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            dialog.get_data()
        return

    def onPrikazOglasa(self):
        if not self.userData["loginState"]:
            QtWidgets.QMessageBox.warning(self, 
            "Morate Biti Logovani", "Molimo Vas logujte se u VAS nalog!!", QtWidgets.QMessageBox.Ok)
            return

        if self.userData["korisnikTIP"] == 1: #korisnik
            dialog = PrikazZakupljenihOglasaDialog(self.parent(), self.userData)
            if dialog.exec_() == QtWidgets.QDialog.Accepted:
                dataD = dialog.get_data()
            return
        if self.userData["korisnikTIP"] == 2: #agencija
            dialog = PrikazPostavljenihOglasaDialog(self.parent(), self.userData)
            if dialog.exec_() == QtWidgets.QDialog.Accepted:
                dataD = dialog.get_data()
            self.set_model()    
        return
            
        

    def onSetUp(self):

        self.hbox_layout.addWidget(self.login_btn)
        self.hbox_layout.addWidget(self.register_btn)
        self.hbox_layout.addWidget(self.detalji_oglasa)
        self.hbox_layout.addWidget(self.prikaz_oglasa)

        self.table_view.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)

        self.vbox_layout.addLayout(self.hbox_layout)
        self.vbox_layout.addWidget(self.table_view)
        

        self.login_btn.clicked.connect(self.onLogin)
        self.register_btn.clicked.connect(self.onRegister)
        self.detalji_oglasa.clicked.connect(self.onDetaljiOglasa)
        self.prikaz_oglasa.clicked.connect(self.onPrikazOglasa)


        self.setLayout(self.vbox_layout)

    def set_model(self):
        self.table_view.setModel(AktuelniOglasiModel())
        self.table_view.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.table_view.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)

