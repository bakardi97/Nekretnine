from plugin_framework.plugin import Plugin
from .widgets.nekretnine_widget import NekretnineWidget

class Main(Plugin):
    def __init__(self, spec):
        super().__init__(spec)

    def get_widget(self, parent=None):
        return NekretnineWidget(parent), None, None