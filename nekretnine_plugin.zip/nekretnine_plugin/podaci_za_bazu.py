import sqlite3
def db_connect():
    return sqlite3.connect('plugins/nekretnine_plugin/BAZA.db')
