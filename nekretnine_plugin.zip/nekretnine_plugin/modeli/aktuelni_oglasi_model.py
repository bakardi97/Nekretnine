from PySide2 import QtCore
from ..podaci_za_bazu import db_connect

class AktuelniOglasiModel(QtCore.QAbstractTableModel):

    def __init__(self):
        super().__init__()
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self._data = []
        self.loadData()

    def rowCount(self, index):
        return len(self._data)

    def columnCount(self, index):
        return 4 

    def data(self, index, role):
        element = self.get_element(index)
        if element is None:
            return None

        if role == QtCore.Qt.DisplayRole:
            return element

    def headerData(self, section, orientation, role):
        if orientation != QtCore.Qt.Vertical:
            if (section == 0) and (role == QtCore.Qt.DisplayRole):
                return "id"
            elif (section == 1) and (role == QtCore.Qt.DisplayRole):
                return "naslov"
            elif (section == 2) and (role == QtCore.Qt.DisplayRole):
                return "tip"
            elif (section == 3) and (role == QtCore.Qt.DisplayRole):
                return "tip nekretnine"


    def setData(self, index, value, role):
        try:
            if value == "":
                return False
            self._data[index.row()][index.column()] = value
            self.dataChanged()
            return True
        except:
            return False

    def flags(self, index):
        return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable

    def get_element(self, index : QtCore.QModelIndex):
        if index.isValid():
            element = self._data[index.row()][index.column()]
            if element:
                return element
        return None

    def loadData(self):
        result = self._conn.execute(""" 
            SELECT oglas_id, podaci_naslov, tip_oglasivanja, vrsta_nekretnine
            FROM oglasi INNER JOIN nekretnine on oglasi.nekretnina_id = nekretnine.id_nekretnina
        """)
        self._data = list(result.fetchall())
        self._conn.commit()

    def getID_clicked(self, index):
        return self._data[index][0]
