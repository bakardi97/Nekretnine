from PySide2 import QtCore
from ..podaci_za_bazu import db_connect

class PostavljeniOglasiModel(QtCore.QAbstractTableModel):

    def __init__(self, idAgencije=None):
        super().__init__()
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self._data = []
        if (idAgencije != None):
            self.loadData(idAgencije)

    def rowCount(self, index):
        return len(self._data)

    def columnCount(self, index):
        return 5

    def data(self, index, role):
        element = self.get_element(index)
        if element is None:
            return None

        if role == QtCore.Qt.DisplayRole:
            return element

    def headerData(self, section, orientation, role):
        if orientation != QtCore.Qt.Vertical:
            if (section == 0) and (role == QtCore.Qt.DisplayRole):
                return "Naslov"
            elif (section == 1) and (role == QtCore.Qt.DisplayRole):
                return "Tip"
            elif (section == 2) and (role == QtCore.Qt.DisplayRole):
                return "Tip Nekretnine"
            elif (section == 3) and (role == QtCore.Qt.DisplayRole):
                return "Lokacija"
            elif (section == 4) and (role == QtCore.Qt.DisplayRole):
                return "Agencija"


    def setData(self, index, value, role):
        try:
            if value == "":
                return False
            self._data[index.row()][index.column()] = value
            self.dataChanged()
            return True
        except:
            return False

    def flags(self, index):
        return QtCore.Qt.ItemIsEnabled

    def get_element(self, index : QtCore.QModelIndex):
        if index.isValid():
            element = self._data[index.row()][index.column()]
            if element:
                return element
        return None

    def loadData(self, idAgencije):
        result = self._conn.execute(""" 
        SELECT podaci_naslov, tip_oglasivanja, vrsta_nekretnine, lokacija, agencija_naziv
        FROM oglasi INNER join nekretnine ON oglasi.nekretnina_id = nekretnine.id_nekretnina
        INNER JOIN agencija ON agencija.agencija_id = nekretnine.agencija_id
		WHERE agencija.agencija_id =:IDa
        """, {"IDa": idAgencije})
        self._data = list(result.fetchall())
        self._conn.commit()

    def getID_clicked(self, index):
        return self._data[index][0]
