from PySide2 import QtCore
from ..podaci_za_bazu import db_connect

class KomentariModel(QtCore.QAbstractTableModel):

    def __init__(self, idOglasa=None):
        super().__init__()
        self._conn = db_connect()
        self._c = self._conn.cursor()
        self._data = []
        if (idOglasa != None):
            self.loadData(idOglasa)

    def rowCount(self, index):
        return len(self._data)

    def columnCount(self, index):
        return 4 

    def data(self, index, role):
        element = self.get_element(index)
        if element is None:
            return None

        if role == QtCore.Qt.DisplayRole:
            return element

    def headerData(self, section, orientation, role):
        if orientation != QtCore.Qt.Vertical:
            if (section == 0) and (role == QtCore.Qt.DisplayRole):
                return "Ime"
            elif (section == 1) and (role == QtCore.Qt.DisplayRole):
                return "Telefon"
            elif (section == 2) and (role == QtCore.Qt.DisplayRole):
                return "Email"
            elif (section == 3) and (role == QtCore.Qt.DisplayRole):
                return "Komentar"


    def setData(self, index, value, role):
        try:
            if value == "":
                return False
            self._data[index.row()][index.column()] = value
            self.dataChanged()
            return True
        except:
            return False

    def flags(self, index):
        return QtCore.Qt.ItemIsEnabled

    def get_element(self, index : QtCore.QModelIndex):
        if index.isValid():
            element = self._data[index.row()][index.column()]
            if element:
                return element
        return None

    def loadData(self, idOglasa):
        result = self._conn.execute(""" 
            SELECT ime_prezime, kontakt_tel, kontakt_email, komentar_tekst
            FROM komentar
            WHERE oglas_id = :id
        """, {"id": idOglasa})
        self._data = list(result.fetchall())
        self._conn.commit()

    def getID_clicked(self, index):
        return self._data[index][0]
